import { Component } from '@angular/core';

@Component({
  selector: 'bp-auth',
  templateUrl: './auth.component.html'
})
export class AuthComponent {

}
